"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _express = _interopRequireDefault(require("express"));

var _api = _interopRequireDefault(require("./api"));

/** Express router for root route
 *
 * @module router
 * @requires express
 */

/**
 * express module
 *
 * @constant
 */

/**
 * Express router to mount all functions
 *
 * @type {object}
 * @constant
 */
var router = _express["default"].Router();

router.use('/api/v1', _api["default"]);
var _default = router;
exports["default"] = _default;