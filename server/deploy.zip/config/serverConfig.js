"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _debug = _interopRequireDefault(require("debug"));

var debug = (0, _debug["default"])('OneStopNews:server');

var ServerConfig = /*#__PURE__*/function () {
  function ServerConfig() {
    (0, _classCallCheck2["default"])(this, ServerConfig);
  }

  (0, _createClass2["default"])(ServerConfig, null, [{
    key: "onError",

    /**
     * Event listener for HTTP server "error" event.
     */

    /**
     * @param error
     * @param port
     */
    value: function onError(error, port) {
      if (error.syscall !== 'listen') {
        throw error;
      }

      var bind = typeof port === 'string' ? "Pipe ".concat(port) : "Port ".concat(port); // handle specific listen errors with friendly messages

      switch (error.code) {
        case 'EACCES':
          console.error("".concat(bind, " requires elevated privileges"));
          process.exit(1);
          break;

        case 'EADDRINUSE':
          console.error("".concat(bind, " is already in use"));
          process.exit(1);
          break;

        default:
          throw error;
      }
    }
    /**
     * Event listener for HTTP server "listening" event.
     */

    /**
     * @param server
     */

  }, {
    key: "onListening",
    value: function onListening(server) {
      var addr = server.address();
      var bind = typeof addr === 'string' ? "pipe ".concat(addr) : "port ".concat(addr.port);
      debug("Listening on ".concat(bind));
    }
  }]);
  return ServerConfig;
}();

exports["default"] = ServerConfig;