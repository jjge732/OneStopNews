"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _axios = _interopRequireDefault(require("axios"));

var _article = _interopRequireDefault(require("../article"));

var Guardian = /*#__PURE__*/function () {
  function Guardian() {
    (0, _classCallCheck2["default"])(this, Guardian);
    this.possibleSections = new Set(['arts', 'automobiles', 'books', 'business', 'fashion', 'food', 'health', 'home', 'insider', 'magazine', 'movies', 'nyregion', 'obituaries', 'opinion', 'politics', 'realestate', 'science', 'sports', 'sundayreview', 'technology', 'theater', 't-magazine', 'travel', 'upshot', 'us', 'world']);
  }

  (0, _createClass2["default"])(Guardian, [{
    key: "getArticlesMetaData",
    value: function () {
      var _getArticlesMetaData = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee() {
        var section,
            quantity,
            response,
            results,
            articles,
            i,
            _results$i,
            title,
            webUrl,
            _args = arguments;

        return _regenerator["default"].wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                section = _args.length > 0 && _args[0] !== undefined ? _args[0] : 'home';
                quantity = _args.length > 1 && _args[1] !== undefined ? _args[1] : 1;

                if (!this.possibleSections.has(section)) {
                  _context.next = 13;
                  break;
                }

                if (section != 'home') {
                  section = "&q=".concat(section);
                } else {
                  section = '';
                }

                _context.next = 6;
                return _axios["default"].get("http://content.guardianapis.com/search?api-key=".concat(process.env.GUARDIAN_API_KEY, "&order-by=newest").concat(section));

              case 6:
                response = _context.sent;

                if (!(quantity > 0)) {
                  _context.next = 12;
                  break;
                }

                results = response.data.response.results;
                articles = new Array(Math.min(quantity, results.length));

                for (i = 0; i < articles.length; i++) {
                  _results$i = results[i], title = _results$i.webTitle, webUrl = _results$i.webUrl;
                  articles[i] = new _article["default"](title, webUrl, 'guardian');
                }

                return _context.abrupt("return", articles);

              case 12:
                return _context.abrupt("return", 'Quantity must be greater than 0');

              case 13:
                return _context.abrupt("return", 'Invalid Section');

              case 14:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function getArticlesMetaData() {
        return _getArticlesMetaData.apply(this, arguments);
      }

      return getArticlesMetaData;
    }()
  }]);
  return Guardian;
}();

exports["default"] = Guardian;