"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _guardian = _interopRequireDefault(require("./newspaperApis/guardian"));

var _nyt = _interopRequireDefault(require("./newspaperApis/nyt"));

/* eslint-disable */
if (process.env.NODE_ENV === 'dev') {
  // imports can only be done at the top level so require is used here
  require('dotenv').config();
}
/* eslint-enable */


var Model = function Model() {
  (0, _classCallCheck2["default"])(this, Model);
  this.guardian = new _guardian["default"]();
  this.nyt = new _nyt["default"]();
};

exports["default"] = Model;