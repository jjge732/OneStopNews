"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime/helpers/toConsumableArray"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _model = _interopRequireDefault(require("../model"));

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

var model = new _model["default"]();
/**
 * @param arr
 */

function shuffleArr(arr) {
  var newArr = new Array(arr.length);

  for (var i = 0; i < arr.length; i++) {
    var j = Math.floor(Math.random() * i);
    newArr[i] = arr[j];
    newArr[j] = arr[i];
  }

  return newArr;
}
/**
 * @param res
 * @param sourceMap
 * @param sources
 * @param section
 * @param quantity
 */


function getArticlesFromMultipleSources(_x, _x2, _x3, _x4) {
  return _getArticlesFromMultipleSources.apply(this, arguments);
}

function _getArticlesFromMultipleSources() {
  _getArticlesFromMultipleSources = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee2(res, sourceMap, section, quantity) {
    var responseArr, error, _iterator, _step, source, resultsArr;

    return _regenerator["default"].wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            responseArr = [];
            error = null;
            _iterator = _createForOfIteratorHelper(sourceMap.values());
            _context2.prev = 3;

            _iterator.s();

          case 5:
            if ((_step = _iterator.n()).done) {
              _context2.next = 13;
              break;
            }

            source = _step.value;
            _context2.next = 9;
            return source.getArticlesMetaData(section, quantity);

          case 9:
            resultsArr = _context2.sent;
            responseArr = [].concat((0, _toConsumableArray2["default"])(responseArr), (0, _toConsumableArray2["default"])(resultsArr));

          case 11:
            _context2.next = 5;
            break;

          case 13:
            _context2.next = 18;
            break;

          case 15:
            _context2.prev = 15;
            _context2.t0 = _context2["catch"](3);

            _iterator.e(_context2.t0);

          case 18:
            _context2.prev = 18;

            _iterator.f();

            return _context2.finish(18);

          case 21:
            responseArr = shuffleArr(responseArr);

            if (!(responseArr.length === 0)) {
              _context2.next = 25;
              break;
            }

            res.status(400).json(error);
            return _context2.abrupt("return");

          case 25:
            if (error != null) {
              console.log(error);
            }

            res.status(res.statusCode).json(responseArr.slice(0, Math.min(parseInt(quantity, 10), responseArr.length)));

          case 27:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, null, [[3, 15, 18, 21]]);
  }));
  return _getArticlesFromMultipleSources.apply(this, arguments);
}

var Articles = /*#__PURE__*/function () {
  function Articles() {
    (0, _classCallCheck2["default"])(this, Articles);
  }

  (0, _createClass2["default"])(Articles, null, [{
    key: "getArticlesMetaData",
    value: function () {
      var _getArticlesMetaData = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(req, res, next) {
        var sourceMap, _req$query, section, source, quantity;

        return _regenerator["default"].wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                sourceMap = new Map([['guardian', model.guardian], ['nyt', model.nyt]]);
                _req$query = req.query, section = _req$query.section, source = _req$query.source;
                quantity = req.query.quantity || 1;

                if (!(/\D/.test(quantity) || quantity < 1)) {
                  _context.next = 7;
                  break;
                }

                res.status(400).json({
                  message: 'Quantity must be an integer greater than 0.'
                });
                _context.next = 19;
                break;

              case 7:
                if (!sourceMap.has(source)) {
                  _context.next = 13;
                  break;
                }

                quantity = parseInt(quantity, 10);
                _context.next = 11;
                return sourceMap.get(source).getArticlesMetaData(section, quantity).then(function (response) {
                  return res.status(200).json(response);
                })["catch"](function (err) {
                  return res.status(400).json(err);
                });

              case 11:
                _context.next = 19;
                break;

              case 13:
                if (!(source != null)) {
                  _context.next = 17;
                  break;
                }

                res.status(400).json({
                  message: 'Unsupported news source. Please send only one of the following sources',
                  sources: (0, _toConsumableArray2["default"])(sourceMap.keys())
                });
                _context.next = 19;
                break;

              case 17:
                _context.next = 19;
                return getArticlesFromMultipleSources(res, sourceMap, section, quantity);

              case 19:
                next();

              case 20:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      function getArticlesMetaData(_x5, _x6, _x7) {
        return _getArticlesMetaData.apply(this, arguments);
      }

      return getArticlesMetaData;
    }()
  }]);
  return Articles;
}();

exports["default"] = Articles;