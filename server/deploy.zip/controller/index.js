"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _articles = _interopRequireDefault(require("./articles"));

var Controller = function Controller() {
  (0, _classCallCheck2["default"])(this, Controller);
  var articles = new _articles["default"]();
  this.articles = {
    getArticlesMetaData: _articles["default"].getArticlesMetaData.bind(articles)
  };
};

exports["default"] = Controller;