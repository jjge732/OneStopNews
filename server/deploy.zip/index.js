#!/usr/bin/env node
'use strict';
/**
 * Module dependencies.
 */

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _awsServerlessExpress = _interopRequireDefault(require("aws-serverless-express"));

var _config = _interopRequireDefault(require("./config"));

/**
 * Create HTTP server.
 */
var server = _awsServerlessExpress["default"].createServer(_config["default"]);

exports.handler = function (event, context) {
  _awsServerlessExpress["default"].proxy(server, event, context);
};